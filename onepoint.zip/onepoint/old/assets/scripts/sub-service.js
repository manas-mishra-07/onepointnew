let href=window.location.href;
let filename=href.split('/').pop();
let filename_without_ext=filename.split('.')[0];
let city=filename_without_ext.split('-').pop();
let service_name=filename_without_ext.replaceAll('-',' ');
$('.mx-2').html('You are in '+ city);
$('.title-city-service').text('Best Rated '+service_name);
$.post('../get_subservice.php',{url:filename_without_ext},function(id){
$.post('../get_subservice.php',{service_id:id},function(response){
    $.get('../subservice.json',function(subservice){
        $('.serviceSelection').empty();
         $.each(subservice,function(index){
    let block='<div class="col serviceItem">'+
    '<a href="#" class="card rounded-3 text-center text-reset text-decoration-none text-capitalize justify-content-center">'+
     '<div class="card-body"><img src="../assets/images/'+subservice[index].image+'" alt="service-1" class="serviceIcon">'+
      '<div class="serviceTitle">'+subservice[index].title+'</div></div></a></div>';
            $('.serviceSelection').append(block);
         });
    });
    //brands
    $.get('../brands.json',function(brands){
        //$('.brandsSwiper').empty();
         $.each(brands,function(index){
    let single_brand='<div class="swiper-slide swiper-slide-duplicate" style="width: auto; margin-right: 30px;" data-swiper-slide-index="0" role="group" aria-label="1 / 8">'+
    '<img src="../assets/images/'+brands[index].image+'" alt="blue-star" class="img-fluid"></div>';
           // $('.brandsSwiper').append(single_brand);
         });
    });
   });
});

//Professionals  servProfessRow
$.get('../tasks.json',function(data){
     $('.storeServices > .row').empty();
     $.each(data,function(index){
     $.post('../get_subservice.php',{taskid:data[index].service_task_id},function(response){
        let json=JSON.parse(response);
               let card='<div class="col-12"><div class="card subServiceCard rounded-3">'+
               '<div class="card-body p-2 p-md-3"><div class="row">'+
             '<div class="col-3 col-md-auto pe-0">'+
              '<img class="img-fluid subServiceImg" src="../assets/images/service-gas-filling.webp" alt="gas-filling"></div>'+
             '<div class="col"><div class="row flex-nowarp h-100 align-items-center">'+
             '<div class="col pe-0"><div class="card-title text-primary fw-bold mb-0">'+json.task_name+
        '<span class="ms-1 badge bg-warning rounded-circle p-1" data-bs-placement="top" data-bs-toggle="tooltip" data-bs-title="Service Explanation">'+
        '<i class="fa-solid fa-exclamation"></i></span></div>'+
        '<p class="card-text text-muted mt-1 mb-0">Best Service Availabe in the town</p></div>'+
        '<div class="col-auto text-end"><div class="subServicePrice fw-bold lh-1"><span>₹</span>'+json.task_price+
        '<p class="small text-muted fs-normal mt-1">(Tax Included)</p></div></div></div></div></div></div>'+
        '<div class="card-footer p-2 p-md-3 border-top-0 text-end"><a href="javascript:;" class="btn-add btn btn-primary btn-sm text-white ms-auto fw-bold">Add Now'+
        '</a></div></div></div>';
     
         
          $('.storeServices > .row').append(card);
     });
     });
});
