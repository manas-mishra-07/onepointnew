<?php
 spl_autoload_register(function($file){
    require_once __DIR__.'/includes/'.$file.'.php';
});
?>