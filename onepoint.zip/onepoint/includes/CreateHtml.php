<?php
class CreateHtml{
    public function makeHtml(object $obj,string $table){
       foreach($obj->select($table) as $reco){
        $filename=$reco['url'].'.html';
       if(!file_exists($filename)){
           fopen($filename,'w');
           copy('city.html',$filename);
      }
       }
    }
    public function create_json($json,$data){
        $file=fopen($json,'w');
        fwrite($file,json_encode($data));
        fclose($file);
    }
}
?>